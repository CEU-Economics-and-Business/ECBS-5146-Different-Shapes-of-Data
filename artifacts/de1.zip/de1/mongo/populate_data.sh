#!/bin/sh


BASEDIR=$(dirname $(realpath "$0"))
echo $BASEDIR/airbnb.json.zip
cd $BASEDIR

unzip -o $BASEDIR/airbnb.json.zip
docker cp $BASEDIR/airbnb.json mongo:/tmp/
docker exec -T mongo mongoimport --host=localhost --port=27017 --bypassDocumentValidation --legacy --collection=airbnb --db=mydatabase --file=/tmp/airbnb.json







