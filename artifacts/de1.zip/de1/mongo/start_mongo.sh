#!/bin/sh

BASE_DIR=`pwd`

sudo docker run --restart unless-stopped --name mongo -it -p 27017:27017 -d mongo:latest 

