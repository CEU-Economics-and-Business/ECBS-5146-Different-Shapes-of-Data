#!/bin/sh

BASE_DIR=`pwd`

docker stop mysql
docker stop solr
docker stop redis
docker stop mongo

docker rm mysql
docker rm solr
docker rm redis
docker rm mongo