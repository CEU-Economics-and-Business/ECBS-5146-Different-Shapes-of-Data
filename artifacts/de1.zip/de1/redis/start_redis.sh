#!/bin/sh

BASE_DIR=`pwd`

sudo docker run --restart unless-stopped --name redis -p 8082:6379 -d redis:latest 

