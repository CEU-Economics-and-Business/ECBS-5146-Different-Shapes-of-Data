#!/bin/sh


BASEDIR=$(dirname $(realpath "$0"))
echo "$BASEDIR"
cd $BASEDIR


unzip -o $BASEDIR/flightdelays.csv.zip
docker exec -i solr bin/solr create -c flightdelays -n data_driven_schema_configs
docker cp $BASEDIR/flightdelays.csv solr:/opt/solr
docker exec -i solr bin/post -c flightdelays flightdelays.csv
docker cp $BASEDIR/security.json solr:/var/solr/data
sudo docker restart solr








