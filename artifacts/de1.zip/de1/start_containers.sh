#!/bin/sh

BASE_DIR=`pwd`

./mongo/start_mongo.sh
./mongo/populate_data.sh

./mysql/start_mysql.sh

./redis/start_redis.sh

./solr/start_solr.sh
./solr/populate_data.sh






































#regi cuccok
#docker run -p 80:8080 --restart unless-stopped -v $BASE_DIR/zeppelin/conf:/zeppelin/conf -v $BASE_DIR/zeppelin/logs:/logs -v $BASE_DIR/zeppelin/interpreter/mysql:/zeppelin/interpreter/mysql -v $BASE_DIR/zeppelin/notebook:/notebook -e ZEPPELIN_LOG_DIR='/logs' -e ZEPPELIN_NOTEBOOK_DIR='/notebook' --link ceudsd-mysql:mysql --name zeppelin apache/zeppelin:0.8.1
#docker run -p 80:8080 --rm --name zeppelin apache/zeppelin:0.8.0
#docker run -p 80:8080 --rm -v $PWD/run:/zeppelin/run -v $PWD/logs:/logs -v $PWD/notebook:/notebook -e ZEPPELIN_LOG_DIR='/logs' -e ZEPPELIN_NOTEBOOK_DIR='/notebook' --name zeppelin apache/zeppelin:0.8.0



