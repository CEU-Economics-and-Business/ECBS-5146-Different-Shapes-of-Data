#!/bin/sh

echo '------------ MOUNT JUPYTER!'
sudo mount --bind /home/ubuntu/de1/jupyter/ /home/jupyter-admin/ceu
chown -R jupyter-admin /home/jupyter-admin/ceu