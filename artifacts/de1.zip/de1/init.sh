#!/bin/sh

### BEGIN INIT INFO
# Required-Start:    $all
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
### END INIT INFO

echo '------------ MOUNT JUPYTER!'
sudo mount --bind /home/ubuntu/de1/jupyter/ /home/jupyter-admin/ceu
chown -R jupyter-admin /home/jupyter-admin/ceu