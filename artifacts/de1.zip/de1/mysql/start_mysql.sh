#!/bin/sh


BASEDIR=$(dirname $(realpath "$0"))
echo $BASEDIR/docker-entrypoint-initdb.d
cd $BASEDIR


docker run --name mysql --restart unless-stopped -p 3306:3306 -v $BASEDIR/docker-entrypoint-initdb.d:/docker-entrypoint-initdb.d -e MYSQL_ROOT_PASSWORD=ceudsd666 -d mysql/mysql-server:latest

